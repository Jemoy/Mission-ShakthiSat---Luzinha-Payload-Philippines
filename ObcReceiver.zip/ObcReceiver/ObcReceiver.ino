/* =====================================================================
 *  ObcReceiver.ino
 *  ---------------------------------------------------------------------
 *  Main-OBC side of the payload link. Receives the payload's plain-text
 *  file frames, verifies them, and reports.
 *
 *  Frame format:
 *      <FRAME 639A_000030>
 *      sec,tmp0_C,...            <- column header
 *      0,-11.1,...               <- data rows
 *      <END 639A_000030 1994 A3F19C22>
 *                     |    |
 *                     |    CRC32 of the body, poly 0xEDB88320
 *                     byte count of the body
 *
 *  The body is every byte between the newline that ends the <FRAME> line
 *  and the '<' of <END>, including each row's own line terminator.
 *
 *  STREAMING, NOT BUFFERED
 *  A heartbeat is ~2 kB but a RESEND of an hourly file is ~230 kB, far
 *  more than RAM. So the body is never held: bytes are fed into a
 *  running CRC as they arrive, and only one line is buffered at a time.
 *  A line is only known to be the <END> terminator once it is complete,
 *  which is why the previous line is folded into the CRC one line late.
 *
 *  Type commands into the Serial Monitor to talk back to the payload:
 *      LIST                  stored files and sizes
 *      STATUS                uptime, counters, free space
 *      RESEND 639A_003600     stream a stored file back
 * ===================================================================== */

#include <Arduino.h>

/* =====================================================================
 *  CONFIGURATION
 * ===================================================================== */

#define PAYLOAD_UART     Serial1
#define PAYLOAD_BAUD     115200

#if defined(ESP32)
  #define PAYLOAD_RX_PIN 16      /* wire to the payload's TX */
  #define PAYLOAD_TX_PIN 17      /* wire to the payload's RX */
#endif

/* Heartbeat cadence. Filenames step by this many seconds, so a larger
 * jump means a beat was missed and tells you exactly which seconds.   */
#define EXPECTED_STEP_S  30
#define LATE_WARN_MS     40000UL   /* warn if no frame for this long   */

#define LINE_MAX         320       /* longest line we expect           */

/* Receive buffer. Must exceed one frame (~1.8 kB) with margin, or a
 * burst overflows while this sketch is doing anything else. 4 kB holds
 * two frames. Applied before begin(); see setup().                    */
#define RX_BUFFER_BYTES  4096

/* ---------------------------------------------------------------------
 *  Showing file contents
 *
 *    PRINT_NONE      verification summary only
 *    PRINT_ALL       every row. Fine for a 30-row heartbeat, but a
 *                    RESEND of an hourly file is 3600 rows and will
 *                    bury the monitor.
 *    PRINT_HEADTAIL  first HEAD_ROWS and last TAIL_ROWS of each frame,
 *                    which is enough to see the shape and the time
 *                    range of any file regardless of size.
 * ------------------------------------------------------------------- */
#define PRINT_NONE       0
#define PRINT_ALL        1
#define PRINT_HEADTAIL   2

/* Printing during reception is what caused the overflow in the first
 * place: each row is ~100 characters, and seven rows plus headers is
 * roughly 80 ms of blocking console writes inside a 157 ms burst.
 *
 * PRINT_HEADTAIL is now deferred -- rows are buffered and printed after
 * the frame is complete and verified, so nothing blocks mid-burst.
 * PRINT_ALL still prints as it goes and will drop bytes on a busy link;
 * use it only for short frames or when debugging the parser itself.  */
#define PRINT_ROWS       PRINT_HEADTAIL
#define HEAD_ROWS        4
#define TAIL_ROWS        3

/* ---------------------------------------------------------------------
 *  Local storage
 *
 *  The OBC keeps its own copy of every VERIFIED frame, so the data
 *  survives the payload pruning its ring or being power-cycled. A frame
 *  that fails its CRC is deleted rather than kept, so anything on disk
 *  here is known good.
 *
 *  Bodies are written as they stream, never buffered: a RESEND is ~230 kB.
 * ------------------------------------------------------------------- */
#define STORE_FILES      1
#define MIN_FREE_BYTES   (32UL * 1024UL)

#if STORE_FILES
  #include <LittleFS.h>
  #define FS_HANDLE LittleFS
#endif

/* =====================================================================
 *  CRC32  (reflected polynomial 0xEDB88320) - incremental
 * ===================================================================== */
static uint32_t crc32_init() { return 0xFFFFFFFFUL; }

static uint32_t crc32_update(uint32_t crc, const uint8_t *d, uint16_t n)
{
  for (uint16_t i = 0; i < n; i++) {
    crc ^= d[i];
    for (uint8_t k = 0; k < 8; k++)
      crc = (crc & 1) ? (crc >> 1) ^ 0xEDB88320UL : (crc >> 1);
  }
  return crc;
}

static uint32_t crc32_final(uint32_t crc) { return ~crc; }

/* =====================================================================
 *  STATE
 * ===================================================================== */
enum RxState { WAIT_FILE, IN_BODY };

static RxState  state = WAIT_FILE;
static char     line[LINE_MAX];
static uint16_t lineLen = 0;

/* One line is held back: we cannot fold it into the CRC until we know
 * it is not the <END> terminator.                                     */
static char     held[LINE_MAX];
static uint16_t heldLen = 0;
static bool     haveHeld = false;

static char     fileName[32];
static uint32_t bodyBytes = 0;
static uint32_t bodyCrc = 0;
static uint32_t rowCount = 0;

static uint32_t filesOk = 0, filesBad = 0, gaps = 0;
static uint32_t lastNumber = 0;
static bool     haveLast = false;
static uint32_t lastFrameMs = 0;
static bool     warnedLate = false;

/* =====================================================================
 *  LOCAL STORAGE
 * ===================================================================== */
#if STORE_FILES
static File     outFile;
static bool     storing = false;
static uint32_t storedFiles = 0;
static uint32_t storeErrors = 0;

static uint32_t freeBytes(void)
{
  return (uint32_t)(FS_HANDLE.totalBytes() - FS_HANDLE.usedBytes());
}

static void storeOpen(const char *name)
{
  char path[40];
  snprintf(path, sizeof(path), "/%s", name);

  if (freeBytes() < MIN_FREE_BYTES) {
    Serial.println(F("  ** disk nearly full - not storing"));
    storing = false;
    return;
  }
  if (FS_HANDLE.exists(path)) FS_HANDLE.remove(path);

  outFile = FS_HANDLE.open(path, FILE_WRITE);
  storing = (bool)outFile;
  if (!storing) {
    storeErrors++;
    Serial.println(F("  ** cannot open local file"));
  }
}

static void storeWrite(const char *d, uint16_t n)
{
  if (storing && n) outFile.write((const uint8_t *)d, n);
}

/* Keep the file only if the frame verified. A bad frame on disk is worse
 * than no frame: it looks like data.                                   */
static void storeClose(const char *name, bool ok)
{
  if (!storing) return;
  outFile.close();
  storing = false;

  if (ok) { storedFiles++; return; }

  char path[40];
  snprintf(path, sizeof(path), "/%s", name);
  FS_HANDLE.remove(path);
  Serial.println(F("  ** frame failed - local copy discarded"));
}
#endif /* STORE_FILES */

/* =====================================================================
 *  HELPERS
 * ===================================================================== */

/* Numeric part of 639A_003600 -> 3600 */
static uint32_t nameNumber(const char *n)
{
  const char *u = strchr(n, '_');
  return u ? (uint32_t)strtoul(u + 1, nullptr, 10) : 0;
}

#if PRINT_ROWS == PRINT_HEADTAIL
/* Rows are BUFFERED during reception and printed only once the frame is
 * complete. Printing mid-burst is what overflowed the UART: a frame
 * arrives in 157 ms, and seven rows of console output takes about 80 ms
 * of that, during which incoming bytes are dropped.
 *
 * Cost: HEAD_ROWS + TAIL_ROWS line buffers, about 2.2 kB. Constant
 * regardless of frame size -- a 3,600-row RESEND uses the same.        */
static char     headBuf[HEAD_ROWS][LINE_MAX];
static uint16_t headLen[HEAD_ROWS];
static uint8_t  headCount = 0;

static char     tailBuf[TAIL_ROWS][LINE_MAX];
static uint16_t tailLen[TAIL_ROWS];
static uint8_t  tailNext = 0;
static uint32_t tailCount = 0;

static void rowsReset(void)
{
  headCount = 0;
  tailNext  = 0;
  tailCount = 0;
}

static void headPush(const char *s, uint16_t n)
{
  if (headCount >= HEAD_ROWS) return;
  if (n >= LINE_MAX) n = LINE_MAX - 1;
  memcpy(headBuf[headCount], s, n);
  headLen[headCount] = n;
  headCount++;
}

static void tailPush(const char *s, uint16_t n)
{
  if (n >= LINE_MAX) n = LINE_MAX - 1;
  memcpy(tailBuf[tailNext], s, n);
  tailLen[tailNext] = n;
  tailNext = (uint8_t)((tailNext + 1) % TAIL_ROWS);
  tailCount++;
}

/* Called after <END> has been parsed, so the link is idle. */
static void rowsFlush(uint32_t total)
{
  for (uint8_t i = 0; i < headCount; i++) {
    headBuf[i][headLen[i]] = 0;
    Serial.print(F("      "));
    Serial.println(headBuf[i]);
  }

  uint8_t n = (uint8_t)((tailCount < TAIL_ROWS) ? tailCount : TAIL_ROWS);
  if (total > (uint32_t)(HEAD_ROWS + n)) Serial.println(F("      ..."));

  uint8_t start = (uint8_t)((tailNext + TAIL_ROWS - n) % TAIL_ROWS);
  for (uint8_t i = 0; i < n; i++) {
    uint8_t k = (uint8_t)((start + i) % TAIL_ROWS);
    if (total - n + i < (uint32_t)HEAD_ROWS) continue;   /* already in head */
    tailBuf[k][tailLen[k]] = 0;
    Serial.print(F("      "));
    Serial.println(tailBuf[k]);
  }
  rowsReset();
}
#endif

static void printBodyLine(const char *s, uint16_t n, uint32_t index)
{
#if PRINT_ROWS == PRINT_ALL
  /* Prints as it goes. Will drop bytes on a busy link -- debugging only. */
  (void)index;
  char tmp[LINE_MAX];
  memcpy(tmp, s, n); tmp[n] = 0;
  Serial.print(F("      "));
  Serial.println(tmp);
#elif PRINT_ROWS == PRINT_HEADTAIL
  if (index < (uint32_t)HEAD_ROWS) headPush(s, n);
  tailPush(s, n);
#else
  (void)s; (void)n; (void)index;
#endif
}

static void foldHeld(void)
{
  if (!haveHeld) return;
  bodyCrc = crc32_update(bodyCrc, (const uint8_t *)held, heldLen);
  bodyBytes += heldLen;
#if STORE_FILES
  storeWrite(held, heldLen);        /* written as it streams, never buffered */
#endif

  /* Strip the line terminator for display only; the CRC covers the
   * bytes exactly as they arrived.                                    */
  uint16_t show = heldLen;
  while (show && (held[show - 1] == '\n' || held[show - 1] == '\r')) show--;
  printBodyLine(held, show, rowCount);

  rowCount++;
  haveHeld = false;
  heldLen = 0;
}

static void startBody(const char *name)
{
  strncpy(fileName, name, sizeof(fileName) - 1);
  fileName[sizeof(fileName) - 1] = 0;
  bodyCrc = crc32_init();
  bodyBytes = 0;
  rowCount = 0;
  haveHeld = false;
  heldLen = 0;
  state = IN_BODY;
#if PRINT_ROWS == PRINT_HEADTAIL
  rowsReset();
#endif
#if STORE_FILES
  storeOpen(fileName);
#endif
}

static void finishBody(const char *endLine)
{
  char endName[32] = {0};
  unsigned long declared = 0, declaredCrc = 0;

  int fields = sscanf(endLine, "<END %31s %lu %lx>", endName, &declared, &declaredCrc);
  /* Some parsers choke on the trailing '>' being swallowed by %s; the
   * name never contains '>' so trim it defensively.                   */
  char *gt = strchr(endName, '>');
  if (gt) *gt = 0;

  uint32_t actual = crc32_final(bodyCrc);
  bool ok = (fields == 3) &&
            (bodyBytes == declared) &&
            (actual == declaredCrc) &&
            (strcmp(fileName, endName) == 0);

  uint32_t now = millis();
  uint32_t dt = lastFrameMs ? (now - lastFrameMs) : 0;
  lastFrameMs = now;
  warnedLate = false;

  /* Filenames are the sequence number: a step larger than one period
   * means a heartbeat was lost, and says exactly which seconds.       */
  uint32_t num = nameNumber(fileName);
  if (haveLast && num > lastNumber) {
    uint32_t step = num - lastNumber;
    if (step != EXPECTED_STEP_S) {
      gaps++;
      Serial.print(F("  ** gap: "));
      Serial.print(lastNumber);
      Serial.print(F(" -> "));
      Serial.print(num);
      Serial.print(F("  ("));
      Serial.print(step / EXPECTED_STEP_S - 1);
      Serial.println(F(" missed)"));
    }
  }
  if (num) { lastNumber = num; haveLast = true; }

#if PRINT_ROWS != PRINT_NONE
  Serial.print(F("--- "));
  Serial.print(fileName);
  Serial.println(F(" ---"));
#endif
#if PRINT_ROWS == PRINT_HEADTAIL
  rowsFlush(rowCount);
#endif

  Serial.print(ok ? F("[OK ] ") : F("[BAD] "));
  Serial.print(fileName);
  Serial.print(F("  "));
  Serial.print(bodyBytes);
  Serial.print(F(" B  "));
  Serial.print(rowCount);
  Serial.print(F(" lines"));
  if (dt) { Serial.print(F("  +")); Serial.print(dt / 1000.0f, 1); Serial.print(F("s")); }

  if (!ok) {
    if (fields != 3)                 Serial.print(F("  malformed END"));
    if (bodyBytes != declared)     { Serial.print(F("  size!=")); Serial.print(declared); }
    if (actual != declaredCrc) {
      char cbuf[32];
      snprintf(cbuf, sizeof(cbuf), "  crc %08lX!=%08lX",
               (unsigned long)actual, (unsigned long)declaredCrc);
      Serial.print(cbuf);
    }
    if (strcmp(fileName, endName)) { Serial.print(F("  name!=")); Serial.print(endName); }
  }
  Serial.println();

#if STORE_FILES
  storeClose(fileName, ok);
#endif

  ok ? filesOk++ : filesBad++;
  state = WAIT_FILE;
}

/* =====================================================================
 *  BYTE-AT-A-TIME PARSER
 * ===================================================================== */
static void handleLine(void)
{
  line[lineLen] = 0;                 /* NUL only for inspection */

  if (state == WAIT_FILE) {
    if (strncmp(line, "<FRAME ", 7) == 0) {
      char name[32] = {0};
      sscanf(line, "<FRAME %31[^>]>", name);
      startBody(name);
      return;
    }
    /* Command replies and anything else the payload volunteers. */
    if (line[0] == '<' || line[0] == '6') {
      if (lineLen > 1) Serial.println(line);
    }
    return;
  }

  /* IN_BODY */
  if (strncmp(line, "<END ", 5) == 0) {
    /* The held line is the last row and DOES belong to the body. */
    foldHeld();
    finishBody(line);
    return;
  }

  /* A previous line is now known not to be the terminator. */
  foldHeld();
  memcpy(held, line, lineLen);
  heldLen = lineLen;
  haveHeld = true;
}

static void pollPayload(void)
{
  while (PAYLOAD_UART.available()) {
    char c = (char)PAYLOAD_UART.read();

    if (lineLen < LINE_MAX - 1) line[lineLen++] = c;
    else lineLen = 0;                /* overlong: resynchronise */

    if (c == '\n') {
      handleLine();
      lineLen = 0;
    }
  }
}


/* =====================================================================
 *  DISPLAY COMMANDS
 *
 *  All of these stream the file from flash rather than loading it, so a
 *  230 kB RESEND costs the same RAM as a 2 kB heartbeat.
 * ===================================================================== */
#if STORE_FILES

#define MAX_COLS      16
#define TAIL_MAX      20
#define PLOT_WIDTH    60
#define PLOT_HEIGHT   12

/* Open a stored file by name, reporting failure once. */
static File openStored(const char *name)
{
  char path[40];
  snprintf(path, sizeof(path), "/%s", name);
  File f = FS_HANDLE.open(path, FILE_READ);
  if (!f) {
    Serial.print(F("no such file: "));
    Serial.println(name);
  }
  return f;
}

/* Read one line into buf. Returns false at end of file. */
static bool nextLine(File &f, char *buf, uint16_t cap)
{
  uint16_t n = 0;
  if (!f.available()) return false;
  while (f.available()) {
    char c = (char)f.read();
    if (c == '\n') break;
    if (c != '\r' && n < cap - 1) buf[n++] = c;
  }
  buf[n] = 0;
  return true;
}

/* Name of the highest-numbered stored file. */
static bool newestStored(char *dst, size_t cap)
{
  uint32_t best = 0;
  dst[0] = 0;
  File root = FS_HANDLE.open("/");
  for (File f = root.openNextFile(); f; f = root.openNextFile()) {
    uint32_t num = nameNumber(f.name());
    if (num >= best) { best = num; strncpy(dst, f.name(), cap - 1); dst[cap-1] = 0; }
    f.close();
  }
  root.close();
  return dst[0] != 0;
}

/* --- cols: the header line, indexed, so plot/stats args are obvious --- */
static void cmdCols(const char *name)
{
  File f = openStored(name);
  if (!f) return;
  char buf[LINE_MAX];
  if (nextLine(f, buf, sizeof(buf))) {
    uint8_t i = 0;
    char *tok = strtok(buf, ",");
    while (tok && i < MAX_COLS) {
      Serial.print(F("  ["));
      if (i < 10) Serial.print(' ');
      Serial.print(i);
      Serial.print(F("] "));
      Serial.println(tok);
      tok = strtok(nullptr, ",");
      i++;
    }
  }
  f.close();
}

/* --- head / tail --- */
static void cmdHead(const char *name, uint16_t n)
{
  File f = openStored(name);
  if (!f) return;
  char buf[LINE_MAX];
  uint16_t shown = 0;
  while (shown < n && nextLine(f, buf, sizeof(buf))) {
    Serial.print(F("  "));
    Serial.println(buf);
    shown++;
  }
  f.close();
}

static void cmdTail(const char *name, uint16_t n)
{
  if (n > TAIL_MAX) n = TAIL_MAX;
  File f = openStored(name);
  if (!f) return;

  /* Rolling window: the file streams past and only n lines are kept. */
  static char ring[TAIL_MAX][LINE_MAX];
  uint16_t count = 0, next = 0;
  char buf[LINE_MAX];
  while (nextLine(f, buf, sizeof(buf))) {
    strncpy(ring[next], buf, LINE_MAX - 1);
    ring[next][LINE_MAX-1] = 0;
    next = (uint16_t)((next + 1) % n);
    count++;
  }
  f.close();

  uint16_t have = (count < n) ? count : n;
  uint16_t start = (uint16_t)((next + n - have) % n);
  for (uint16_t i = 0; i < have; i++) {
    Serial.print(F("  "));
    Serial.println(ring[(start + i) % n]);
  }
}

/* --- stats: min, max, mean per column, computed in one pass --- */
static void cmdStats(const char *name)
{
  File f = openStored(name);
  if (!f) return;

  char header[LINE_MAX];
  if (!nextLine(f, header, sizeof(header))) { f.close(); return; }

  char names[MAX_COLS][14];
  uint8_t nCols = 0;
  {
    char tmp[LINE_MAX];
    strncpy(tmp, header, sizeof(tmp) - 1); tmp[sizeof(tmp)-1] = 0;
    char *tok = strtok(tmp, ",");
    while (tok && nCols < MAX_COLS) {
      strncpy(names[nCols], tok, 13); names[nCols][13] = 0;
      tok = strtok(nullptr, ","); nCols++;
    }
  }

  float mn[MAX_COLS], mx[MAX_COLS];
  double sum[MAX_COLS];
  for (uint8_t i = 0; i < nCols; i++) { mn[i] = 1e30f; mx[i] = -1e30f; sum[i] = 0; }

  uint32_t rows = 0;
  char buf[LINE_MAX];
  while (nextLine(f, buf, sizeof(buf))) {
    uint8_t i = 0;
    char *tok = strtok(buf, ",");
    while (tok && i < nCols) {
      float v = atof(tok);
      if (v < mn[i]) mn[i] = v;
      if (v > mx[i]) mx[i] = v;
      sum[i] += v;
      tok = strtok(nullptr, ","); i++;
    }
    rows++;
  }
  f.close();

  Serial.print(F("--- ")); Serial.print(name);
  Serial.print(F("  ")); Serial.print(rows); Serial.println(F(" rows ---"));
  Serial.println(F("  col  name             min       max      mean"));
  for (uint8_t i = 0; i < nCols; i++) {
    char lineBuf[80];
    snprintf(lineBuf, sizeof(lineBuf), "  [%2u] %-13s %9.3f %9.3f %9.3f",
             i, names[i], (double)mn[i], (double)mx[i],
             rows ? sum[i] / rows : 0.0);
    Serial.println(lineBuf);
  }
}

/* --- plot: ASCII chart of one column across the whole file ---
 * Two passes: the first finds the range, the second buckets rows into
 * PLOT_WIDTH columns. Buckets rather than sampling, so a spike between
 * sample points cannot hide.                                          */
static void cmdPlot(const char *name, uint8_t col)
{
  File f = openStored(name);
  if (!f) return;

  char buf[LINE_MAX];
  nextLine(f, buf, sizeof(buf));                 /* skip header */

  float mn = 1e30f, mx = -1e30f;
  uint32_t rows = 0;
  while (nextLine(f, buf, sizeof(buf))) {
    uint8_t i = 0; char *tok = strtok(buf, ",");
    while (tok && i < col) { tok = strtok(nullptr, ","); i++; }
    if (tok) { float v = atof(tok); if (v < mn) mn = v; if (v > mx) mx = v; }
    rows++;
  }
  if (!rows) { f.close(); Serial.println(F("empty")); return; }

  f.seek(0);
  nextLine(f, buf, sizeof(buf));
  char header[LINE_MAX]; strncpy(header, buf, sizeof(header)-1); header[sizeof(header)-1]=0;

  /* Never more buckets than rows, or half of them come out empty and
   * plot as zero - which looks like a signal dropout that is not there. */
  uint8_t width = (rows < PLOT_WIDTH) ? (uint8_t)rows : PLOT_WIDTH;

  float bucket[PLOT_WIDTH];
  uint16_t bn[PLOT_WIDTH];
  for (uint8_t i = 0; i < width; i++) { bucket[i] = 0; bn[i] = 0; }

  uint32_t r = 0;
  while (nextLine(f, buf, sizeof(buf))) {
    uint8_t i = 0; char *tok = strtok(buf, ",");
    while (tok && i < col) { tok = strtok(nullptr, ","); i++; }
    if (tok) {
      uint16_t b = (uint16_t)((uint64_t)r * width / rows);
      if (b >= width) b = width - 1;
      bucket[b] += atof(tok); bn[b]++;
    }
    r++;
  }
  f.close();

  for (uint8_t i = 0; i < width; i++) if (bn[i]) bucket[i] /= bn[i];

  /* Column name from the header, for the title. */
  char cname[16] = "?";
  { uint8_t i = 0; char *tok = strtok(header, ",");
    while (tok) { if (i == col) { strncpy(cname, tok, 15); cname[15]=0; break; }
                  tok = strtok(nullptr, ","); i++; } }

  char title[96];
  snprintf(title, sizeof(title), "--- %s  col %u (%s)  %.3f .. %.3f  %lu rows ---",
           name, col, cname, (double)mn, (double)mx, (unsigned long)rows);
  Serial.println(title);

  float span = (mx - mn);
  if (span < 1e-9f) span = 1e-9f;
  for (int8_t row = PLOT_HEIGHT - 1; row >= 0; row--) {
    float level = mn + span * (row + 0.5f) / PLOT_HEIGHT;
    char lineBuf[PLOT_WIDTH + 16];
    snprintf(lineBuf, sizeof(lineBuf), "%8.2f |", (double)level);
    Serial.print(lineBuf);
    for (uint8_t i = 0; i < width; i++) {
      uint8_t h = (uint8_t)((bucket[i] - mn) / span * PLOT_HEIGHT);
      Serial.print(h >= (uint8_t)row ? '#' : ' ');
    }
    Serial.println();
  }
  Serial.print(F("         +"));
  for (uint8_t i = 0; i < width; i++) Serial.print('-');
  Serial.println();
}
#endif /* STORE_FILES */

/* =====================================================================
 *  CONSOLE -> PAYLOAD
 * ===================================================================== */
static char consoleBuf[64];
static uint8_t consoleLen = 0;

/* UPPERCASE goes to the payload, lowercase acts on this board. Keeps the
 * two namespaces apart with no prefix to remember.                     */
static void printHelp(void)
{
  Serial.println(F("payload : LIST  STATUS  CLOSE  RESEND <name>"));
  Serial.println(F("browse  : ls   last   cat|head|tail <name> [n]"));
  Serial.println(F("inspect : cols <name>   stats <name>   plot <name> <col>"));
  Serial.println(F("manage  : rm <name>|all   free   ?   show off|head|all"));
  Serial.println(F("(a bare name after last/cat/... may be omitted to use the newest file)"));
}

#if STORE_FILES
static void localLs(void)
{
  uint16_t n = 0;
  uint32_t total = 0;
  Serial.println(F("--- stored on OBC ---"));
  File root = FS_HANDLE.open("/");
  for (File f = root.openNextFile(); f; f = root.openNextFile()) {
    Serial.print(F("  "));
    Serial.print(f.name());
    Serial.print(F("  "));
    Serial.print((unsigned long)f.size());
    Serial.println(F(" B"));
    total += (uint32_t)f.size();
    n++;
    f.close();
  }
  root.close();
  Serial.print(F("  "));
  Serial.print(n);
  Serial.print(F(" file(s), "));
  Serial.print(total / 1024);
  Serial.print(F(" kB used, "));
  Serial.print(freeBytes() / 1024);
  Serial.println(F(" kB free"));
}

/* Dump a stored file. Printed straight from flash a line at a time, so
 * file size does not matter - a 230 kB file costs no more RAM than a
 * 2 kB one, it just takes longer to scroll.                           */
static void localCat(const char *name)
{
  char path[40];
  snprintf(path, sizeof(path), "/%s", name);
  File f = FS_HANDLE.open(path, FILE_READ);
  if (!f) {
    Serial.print(F("no such file: "));
    Serial.println(name);
    return;
  }
  Serial.print(F("--- "));
  Serial.print(name);
  Serial.print(F("  "));
  Serial.print((unsigned long)f.size());
  Serial.println(F(" B ---"));

  uint32_t lines = 0;
  char buf[LINE_MAX];
  uint16_t n = 0;
  while (f.available()) {
    char c = (char)f.read();
    if (c == '\n') { buf[n] = 0; Serial.println(buf); n = 0; lines++; }
    else if (c != '\r' && n < LINE_MAX - 1) buf[n++] = c;
  }
  if (n) { buf[n] = 0; Serial.println(buf); lines++; }
  f.close();
  Serial.print(F("--- "));
  Serial.print(lines);
  Serial.println(F(" lines ---"));
}

static void localRm(const char *name)
{
  if (!strcmp(name, "all")) {
    uint16_t removed = 0;
    char victim[40];
    for (;;) {
      victim[0] = 0;
      File root = FS_HANDLE.open("/");
      File f = root.openNextFile();
      if (f) { snprintf(victim, sizeof(victim), "/%s", f.name()); f.close(); }
      root.close();
      if (!victim[0] || !FS_HANDLE.remove(victim)) break;
      removed++;
    }
    Serial.print(F("removed "));
    Serial.print(removed);
    Serial.println(F(" file(s)"));
    return;
  }
  char path[40];
  snprintf(path, sizeof(path), "/%s", name);
  Serial.println(FS_HANDLE.remove(path) ? F("removed") : F("not found"));
}
#endif /* STORE_FILES */

static void printStats(void)
{
  Serial.println(F("--- receiver ---"));
  Serial.print(F("  files ok     : ")); Serial.println(filesOk);
  Serial.print(F("  files bad    : ")); Serial.println(filesBad);
  Serial.print(F("  heartbeat gaps: ")); Serial.println(gaps);
#if STORE_FILES
  Serial.print(F("  stored locally: ")); Serial.println(storedFiles);
  Serial.print(F("  store errors  : ")); Serial.println(storeErrors);
#endif
  Serial.print(F("  last name    : "));
  if (haveLast) Serial.println(lastNumber); else Serial.println(F("none"));
}

#if STORE_FILES
/* Runtime control of the live frame display, so a RESEND can be made
 * quiet without reflashing.                                          */
static uint8_t showMode = PRINT_ROWS;

static void setShow(const char *arg)
{
  if      (!strncmp(arg, "off",  3)) showMode = PRINT_NONE;
  else if (!strncmp(arg, "head", 4)) showMode = PRINT_HEADTAIL;
  else if (!strncmp(arg, "all",  3)) showMode = PRINT_ALL;
  else { Serial.println(F("show off|head|all")); return; }
  Serial.print(F("display: "));
  Serial.println(showMode == PRINT_NONE ? F("off")
               : showMode == PRINT_ALL  ? F("all rows") : F("head+tail"));
}

/* Split "cmd [name] [n]" and resolve an omitted name to the newest file,
 * which is almost always the one you want to look at.                */
static void dispatchDisplay(char *line)
{
  char *cmd = strtok(line, " ");
  char *a1  = strtok(nullptr, " ");
  char *a2  = strtok(nullptr, " ");

  /* A file name contains '_' (639A_000600); a bare count does not. Testing
   * the first character would fail, since names start with a digit.   */
  char name[40];
  if (a1 && strchr(a1, '_')) {
    strncpy(name, a1, sizeof(name) - 1); name[sizeof(name)-1] = 0;
  } else {
    if (!newestStored(name, sizeof(name))) { Serial.println(F("nothing stored")); return; }
    a2 = a1;                                  /* the arg was a count */
  }

  uint16_t n = a2 ? (uint16_t)atoi(a2) : 10;
  if (!n) n = 10;

  if      (!strcmp(cmd, "cat")  || !strcmp(cmd, "last")) localCat(name);
  else if (!strcmp(cmd, "head"))  cmdHead(name, n);
  else if (!strcmp(cmd, "tail"))  cmdTail(name, n);
  else if (!strcmp(cmd, "cols"))  cmdCols(name);
  else if (!strcmp(cmd, "stats")) cmdStats(name);
  else if (!strcmp(cmd, "plot"))  cmdPlot(name, a2 ? (uint8_t)atoi(a2) : 1);
}
#endif

static void pollConsole(void)
{
  while (Serial.available()) {
    char c = (char)Serial.read();
    if (c == '\n' || c == '\r') {
      if (!consoleLen) continue;
      consoleBuf[consoleLen] = 0;
      if (consoleBuf[0] == '?')             printStats();
      else if (!strcmp(consoleBuf, "help"))  printHelp();
#if STORE_FILES
      else if (!strcmp(consoleBuf, "ls"))    localLs();
      else if (!strcmp(consoleBuf, "free"))  { Serial.print(freeBytes()/1024); Serial.println(F(" kB free")); }
      else if (!strncmp(consoleBuf, "rm ", 3))  localRm(consoleBuf + 3);
      else if (!strncmp(consoleBuf, "show ", 5)) setShow(consoleBuf + 5);
      else if (!strncmp(consoleBuf, "cat",  3) || !strncmp(consoleBuf, "last", 4) ||
               !strncmp(consoleBuf, "head", 4) || !strncmp(consoleBuf, "tail", 4) ||
               !strncmp(consoleBuf, "cols", 4) || !strncmp(consoleBuf, "stats",5) ||
               !strncmp(consoleBuf, "plot", 4))
        dispatchDisplay(consoleBuf);
#endif
      else {
        PAYLOAD_UART.println(consoleBuf);   /* forward verbatim */
        Serial.print(F("> "));
        Serial.println(consoleBuf);
      }
      consoleLen = 0;
      continue;
    }
    if (consoleLen < sizeof(consoleBuf) - 1) consoleBuf[consoleLen++] = c;
    else consoleLen = 0;
  }
}

/* =====================================================================
 *  SETUP / LOOP
 * ===================================================================== */
void setup()
{
  Serial.begin(115200);
  while (!Serial && millis() < 3000) { }
  delay(200);

  /* -------------------------------------------------------------------
   *  RX buffer, sized to hold a whole frame.
   *
   *  A frame is ~1.8 kB, which at 115200 arrives as a single 157 ms
   *  burst. The default 256-byte buffer holds about 22 ms of that. If
   *  this sketch is busy -- printing to its own console, writing to
   *  flash -- the rest overflows and is gone.
   *
   *  That failure looks exactly like corruption: the CRC fails. But the
   *  byte count in the <END> line is short, not equal, which is how you
   *  tell truncation from corruption. Bytes that never arrived, not
   *  bytes that arrived wrong.
   *
   *  MUST be called BEFORE begin() or it has no effect.
   * ------------------------------------------------------------------- */
#if defined(ESP32)
  PAYLOAD_UART.setRxBufferSize(RX_BUFFER_BYTES);
  PAYLOAD_UART.begin(PAYLOAD_BAUD, SERIAL_8N1, PAYLOAD_RX_PIN, PAYLOAD_TX_PIN);
#else
  PAYLOAD_UART.begin(PAYLOAD_BAUD);
#endif

  Serial.println();
  Serial.println(F("=== OBC receiver ==="));
  Serial.print(F("link       : UART @ ")); Serial.println(PAYLOAD_BAUD);
  Serial.print(F("expect     : one frame every ")); Serial.print(EXPECTED_STEP_S);
  Serial.println(F(" s"));
  Serial.println(F("verify     : byte count + CRC32 (0xEDB88320), streamed"));
#if STORE_FILES
  Serial.print(F("storage    : LittleFS ... "));
  if (!LittleFS.begin(true)) { Serial.println(F("FAILED")); while (1) delay(1000); }
  Serial.print(F("ok, "));
  Serial.print(freeBytes() / 1024);
  Serial.println(F(" kB free"));
#endif
  printHelp();
  Serial.println();
}

void loop()
{
  pollPayload();
  pollConsole();

  /* A missing heartbeat is the payload's liveness signal failing, so
   * say so rather than waiting silently.                              */
  if (lastFrameMs && !warnedLate && (millis() - lastFrameMs) > LATE_WARN_MS) {
    warnedLate = true;
    Serial.print(F("  ** no frame for "));
    Serial.print((millis() - lastFrameMs) / 1000);
    Serial.println(F(" s - payload may be down"));
  }
}
